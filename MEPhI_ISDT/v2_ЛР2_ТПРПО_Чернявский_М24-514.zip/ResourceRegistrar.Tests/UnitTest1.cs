using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ResourceRegistrar;

namespace ResourceRegistrar.Tests
{
    [TestClass]
    public class ResourceManagerTests
    {
        private ResourceManager _manager;

        [TestInitialize]
        public void Init()
        {
            // Инициализация менеджера с 5 ресурсами ёмкостью 10
            var resources = Enumerable.Range(1, 5)
                .Select(i => new Resource($"R{i}", capacity: 10))
                .ToList();
            _manager = new ResourceManager(resources);
        }

        //
        // Модульные тесты (базовые сценарии)
        //

        [TestMethod]
        public void Allocate_SinglePart()
        {
            // Запрос размером 5 -> должна выделиться одна часть
            var req = new Request("T1", 5);
            var result = _manager.Allocate(req);

            Assert.IsTrue(result.Success, "Должен успешно выделиться один ресурс");
            Assert.AreEqual(1, result.Parts.Count, "Должна быть ровно одна часть");
        }

        [TestMethod]
        public void Allocate_MultipleParts()
        {
            // Запрос размером 25 -> должна выделиться 3 части
            var req = new Request("T2", 25);
            var result = _manager.Allocate(req);

            Assert.IsTrue(result.Success, "Должен успешно выделиться три ресурса");
            Assert.AreEqual(3, result.Parts.Count, "Должно быть ровно три части");
        }

        [TestMethod]
        public void Allocate_NotEnoughResources()
        {
            // Запрос размером 60 при общей ёмкости 50 -> отказ
            var req = new Request("T3", 60);
            var result = _manager.Allocate(req);

            Assert.IsFalse(result.Success, "При нехватке ресурсов должен быть отказ");
        }

        [TestMethod]
        public void Release_Works()
        {
            // Проверяем, что после Release ресурсы освобождаются
            var req = new Request("T4", 20);
            var allocResult = _manager.Allocate(req);
            Assert.IsTrue(allocResult.Success, "Предварительное выделение должно быть успешным");

            _manager.Release(allocResult.Parts);

            var retry = _manager.Allocate(new Request("T5", 20));
            Assert.IsTrue(retry.Success, "Должно успешно выделяться после освобождения");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Request_InvalidSize_Throws()
        {
            // Нельзя создать запрос с нулевым размером
            new Request("T6", 0);
        }

        //
        // Функциональный тест (end-to-end)
        //

        [TestMethod]
        public void Functional_FullLifecycle_MetricsAndStatus()
        {
            // Выделение и последующая проверка статуса и метрик
            var req1 = new Request("F1", 20);
            var res1 = _manager.Allocate(req1);
            Assert.IsTrue(res1.Success);
            Assert.AreEqual(2, res1.Parts.Count);

            // Проверяем, что заняты ровно 2 ресурса
            var busy = _manager.GetStatus().Where(t => !t.IsFree).Select(t => t.Id).ToList();
            CollectionAssert.AreEquivalent(new[] { "R1", "R2" }, busy);

            // Освобождаем и проверяем, что все ресурсы свободны
            _manager.Release(res1.Parts);
            Assert.IsTrue(_manager.GetStatus().All(t => t.IsFree));

            // Проверяем метрики использования
            var avgUse = _manager.GetAverageUsageTime();
            Assert.IsTrue(avgUse > 0, "AverageUsageTime должно быть > 0 после релиза");
            Assert.AreEqual(0.0, _manager.GetAverageWaitingTime(), "AverageWaitingTime всегда 0 в этой версии");
        }

        //
        // Интеграционный тест (конкурентность)
        //

        [TestMethod]
        public void Concurrency_AllocateRelease_DoesNotCorruptState()
        {
            // Параллельные запросы к ResourceManager
            const int threads = 10;
            const int requestSize = 10;

            var results = new ConcurrentBag<bool>();
            Parallel.For(0, threads, i =>
            {
                var req = new Request($"C{i}", requestSize);
                var r = _manager.Allocate(req);
                if (r.Success)
                {
                    Thread.Sleep(50);
                    _manager.Release(r.Parts);
                }
                results.Add(r.Success);
            });

            // Проверяем, что хотя бы один запрос обработан и нет зависаний
            Assert.IsTrue(results.Count > 0, "Не было обработано ни одного запроса?");
            // Все ресурсы должны быть свободны в конце
            Assert.IsTrue(_manager.GetStatus().All(t => t.IsFree), "Какие-то ресурсы остались заняты");
        }

        //
        // Граничные и стресс-тесты
        //

        [TestMethod]
        public void Boundary_LargeRequestFails()
        {
            // Очень большой запрос -> отказ
            var req = new Request("B1", size: 1000);
            var res = _manager.Allocate(req);
            Assert.IsFalse(res.Success, "Очень большой запрос должен получить отказ");
        }

        [TestMethod]
        public void Boundary_ExactCapacityPlusOne()
        {
            // Общая ёмкость 5*10 = 50, запрос 51 -> отказ
            var req = new Request("B2", size: 51);
            var res = _manager.Allocate(req);
            Assert.IsFalse(res.Success, "Запрос на 51 при общей ёмкости 50 должен провалиться");
        }

        [TestMethod]
        public void Boundary_SequentialExhaustion()
        {
            // Пять запросов по 10 -> исчерпание ресурсов
            for (int i = 0; i < 5; i++)
            {
                var r = _manager.Allocate(new Request($"E{i}", 10));
                Assert.IsTrue(r.Success);
            }
            // Следующий запрос не пройдет
            var fail = _manager.Allocate(new Request("E5", 10));
            Assert.IsFalse(fail.Success, "После исчерпания ресурсов новый запрос не должен пройти");
        }

        //
        // Тест корректности метрик
        //

        [TestMethod]
        public void Metrics_AverageUsageTime_CalculatedCorrectly()
        {
            // Первый цикл ~100ms
            var reqA = new Request("M1", 10);
            var rA = _manager.Allocate(reqA);
            Thread.Sleep(100);
            _manager.Release(rA.Parts);

            // Второй цикл ~200ms
            var reqB = new Request("M2", 10);
            var rB = _manager.Allocate(reqB);
            Thread.Sleep(200);
            _manager.Release(rB.Parts);

            var avg = _manager.GetAverageUsageTime();
            // В секундах ≈ 0.15
            Assert.IsTrue(avg >= 0.14 && avg <= 0.18, $"AverageUsageTime вне ожидаемого диапазона: {avg:F2} сек");
        }
    }
}
