using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ResourceRegistrar;

namespace ResourceRegistrar.Tests
{
    [TestClass]
    public class ResourceManagerTests
    {
        private ResourceManager _manager;

        [TestInitialize]
        public void Init()
        {
            var resources = Enumerable.Range(1, 5)
                .Select(i => new Resource($"R{i}", capacity: 10))
                .ToList();
            _manager = new ResourceManager(resources);
        }

        [TestMethod]
        public void Allocate_SinglePart()
        {
            var req = new Request("T1", 5);
            var result = _manager.Allocate(req);

            Assert.IsTrue(result.Success, "Должен успешно выделиться один ресурс");
            Assert.AreEqual(1, result.Parts.Count, "Должна быть ровно одна часть");
        }

        [TestMethod]
        public void Allocate_MultipleParts()
        {
            var req = new Request("T2", 25);
            var result = _manager.Allocate(req);

            Assert.IsTrue(result.Success, "Должен успешно выделиться три ресурса");
            Assert.AreEqual(3, result.Parts.Count, "Должно быть ровно три части");
        }

        [TestMethod]
        public void Allocate_NotEnoughResources()
        {
            var req = new Request("T3", 60);
            var result = _manager.Allocate(req);

            Assert.IsFalse(result.Success, "При нехватке ресурсов должен быть отказ");
        }

        [TestMethod]
        public void Release_Works()
        {
            var req = new Request("T4", 20);
            var allocResult = _manager.Allocate(req);
            Assert.IsTrue(allocResult.Success, "Предварительное выделение должно быть успешным");

            _manager.Release(allocResult.Parts);

            var retry = _manager.Allocate(new Request("T5", 20));
            Assert.IsTrue(retry.Success, "Должно успешно выделяться после освобождения");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Request_InvalidSize_Throws()
        {
            new Request("T6", 0);
        }
    }
}
