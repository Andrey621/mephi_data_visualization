﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ResourceRegistrar
{
    public class Resource
    {
        
        public string Id { get; }  // Идентификатор ресурса
        
        public int Capacity { get; }  // Максимальная ёмкость ресурса
        
        public bool IsFree { get; private set; } = true;

        public Resource(string id, int capacity)
        {
            Id = id;
            Capacity = capacity;
        }

        // Пытается занять ресурс: если свободен, помечает как занятый и возвращает true
        public bool Allocate()
        {
            if (!IsFree)
                return false;
            IsFree = false;
            return true;
        }

        // Освобождает ресурс: помечает как свободный
        public void Release()
        {
            IsFree = true;
        }
    }

    // Класс RequestPart: часть дробимого запроса, привязанная к конкретному ресурсу
    public class RequestPart
    {
        public string ParentRequestId { get; }
        
        public Resource AllocatedResource { get; }  // Ресурс, выделенный для этой части
        
        public DateTime AllocatedAt { get; }  // Время начала использования ресурса

        public DateTime? ReleasedAt { get; private set; }  // Время освобождения ресурса

        public RequestPart(string parentRequestId, Resource resource)
        {
            ParentRequestId = parentRequestId;
            AllocatedResource = resource;
            AllocatedAt = DateTime.UtcNow;
        }

        public double MarkReleased()
        {
            ReleasedAt = DateTime.UtcNow;
            return (ReleasedAt.Value - AllocatedAt).TotalSeconds;
        }
    }

    public class Request
    {
        
        public string Id { get; } // Идентификатор запроса
        
        public int Size { get; } // Размер запроса (в единицах ресурса)
        
        public List<RequestPart> Parts { get; } = new List<RequestPart>();  // Список частей запроса


        public Request(string id, int size)
        {
            if (size <= 0)
                throw new ArgumentException("Размер запроса должен быть положительным.");
            Id = id;
            Size = size;
        }
    }

    public class AllocationResult
    {
        
        public bool Success { get; } // Успешно ли выделены ресурсы (true — успешно, false — отказ)
        
        public List<RequestPart> Parts { get; } // Список выделенных частей запроса
        
        public string Message { get; } // Сообщение об ошибке или успехе

        private AllocationResult(bool success, List<RequestPart> parts, string message)
        {
            Success = success;
            Parts = parts;
            Message = message;
        }

        public static AllocationResult Ok(List<RequestPart> parts)
            => new AllocationResult(true, parts, "Выделение ресурсов успешно.");

        public static AllocationResult Fail(string message)
            => new AllocationResult(false, new List<RequestPart>(), message);
    }

    public class ResourceManager
    {
        
        private readonly List<Resource> _resources;  // Внутренний список всех ресурсов в системе
        
        private readonly List<double> _usageDurations = new List<double>();  // Список времён использования ресурсов

        // Конструктор: принимает коллекцию ресурсов
        public ResourceManager(IEnumerable<Resource> resources)
        {
            _resources = resources.ToList();
        }

        // Метод Allocate: разбивает запрос на части и пытается выделить ресурсы
        public AllocationResult Allocate(Request request)
        {
            // Считаем, сколько ресурсов нужно: делим объём запроса на ёмкость одного ресурса
            int needed = (int)Math.Ceiling((double)request.Size / _resources.First().Capacity);

            // Находим свободные ресурсы
            var freeResources = _resources.Where(r => r.IsFree).Take(needed).ToList();
            // Если ресурсов меньше, чем требуется, возвращаем отказ
            if (freeResources.Count < needed)
                return AllocationResult.Fail("Недостаточно свободных ресурсов для выполнения запроса.");

            // Иначе резервируем ресурсы: помечаем их занятыми и создаём части запроса
            var parts = new List<RequestPart>();
            foreach (var res in freeResources)
            {
                res.Allocate();                                   // занимаем ресурс
                parts.Add(new RequestPart(request.Id, res));      // создаём часть и фиксируем время
            }

            // Сохраняем части
            request.Parts.AddRange(parts);

            return AllocationResult.Ok(parts);
        }

        // Метод Release: освобождает переданные ресурсы и собирает метрику использования
        public void Release(IEnumerable<RequestPart> parts)
        {
            foreach (var part in parts)
            {
                // Сбрасываем ресурс и фиксируем время использования
                double duration = part.MarkReleased();
                _usageDurations.Add(duration);
                part.AllocatedResource.Release();  // помечаем как свободный
            }
        }

        // Метод GetStatus: возвращает текущее состояние всех ресурсов
        public IEnumerable<(string Id, bool IsFree)> GetStatus()
            => _resources.Select(r => (r.Id, r.IsFree));

        // Возвращает среднее время использования ресурса в секундах
        public double GetAverageUsageTime()
            => _usageDurations.Any() ? _usageDurations.Average() : 0.0;

        // Вариант 2 не подразумевает ожидания, поэтому всегда 0
        public double GetAverageWaitingTime()
            => 0.0;
    }

    // Пример использования
    public static class Program
    {
        public static void Main()
        {
            // создаём 5 ресурсов вместимостью 10 каждый
            var resources = Enumerable.Range(1, 5)
                .Select(i => new Resource($"R{i}", capacity: 10))
                .ToList();

            var manager = new ResourceManager(resources);

            // Клиент отправляет запрос размером 25
            var request = new Request("Req1", size: 25);
            var result = manager.Allocate(request);

            if (result.Success)
            {
                Console.WriteLine($"Выделено частей: {result.Parts.Count}");
                foreach (var part in result.Parts)
                {
                    Console.WriteLine($"  Часть на ресурсе {part.AllocatedResource.Id}");
                }

                // Имитируем работу с ресурсами
                System.Threading.Thread.Sleep(1500);

                manager.Release(result.Parts);
                Console.WriteLine($"Среднее время использования ресурса: {manager.GetAverageUsageTime():F2} сек.");
                Console.WriteLine($"Среднее время ожидания запроса: {manager.GetAverageWaitingTime():F2} сек.");
            }
            else
            {
                Console.WriteLine($"Не удалось выделить ресурсы: {result.Message}");
            }
        }
    }
}
